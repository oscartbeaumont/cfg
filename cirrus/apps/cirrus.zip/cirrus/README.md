# Cirrus Splash Page

## Setup Dokku

```bash
dokku apps:create cirrus
```

## Deploy to Dokku

```bash
git remote add dokku ssh://dokku@cirrus/cirrus
git push dokku master
```
